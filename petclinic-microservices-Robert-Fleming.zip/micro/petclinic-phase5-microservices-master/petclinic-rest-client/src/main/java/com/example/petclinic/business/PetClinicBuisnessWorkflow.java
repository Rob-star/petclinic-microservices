package com.example.petclinic.business;

import com.example.petclinic.PetClinicClient;
import com.example.petclinic.model.Owner;
import com.example.petclinic.model.Pet;
import com.example.petclinic.model.PetType;
import com.example.petclinic.service.OwnerService;
import com.example.petclinic.service.PetService;
import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Null;
import java.util.Date;


@Component
public class PetClinicBuisnessWorkflow {


    OwnerService ownerService;
    PetService petService;

    public PetClinicBuisnessWorkflow(OwnerService ownerService, PetService petService) {
        this.ownerService = ownerService;
        this.petService = petService;
    }


    public void runBusiness() {

        // Create Pets

        Pet pet1 = Pet.builder().withName("Strangles").withBirthDate(new Date()).withPetType(PetType.SNAKE).build();
        Pet pet2 = Pet.builder().withName("Mojo").withBirthDate(new Date()).withPetType(PetType.MONKEY).build();
        Pet pet3 = Pet.builder().withName("Pinchy").withBirthDate(new Date()).withPetType(PetType.LOBSTER).build();
        Pet pet4 = Pet.builder().withName("Plopper").withBirthDate(new Date()).withPetType(PetType.PIG).build();


        //Save Pets

        petService.savePet(pet1);
        petService.savePet(pet2);
        petService.savePet(pet3);
        petService.savePet(pet4);

        //delete

        petService.deletePet(pet1);

        //Get All

        petService.getAllPets();
    }
}

