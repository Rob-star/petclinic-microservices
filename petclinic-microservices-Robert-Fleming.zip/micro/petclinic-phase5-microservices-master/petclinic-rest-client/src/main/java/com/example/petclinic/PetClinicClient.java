package com.example.petclinic;

import com.example.petclinic.config.RestConfig;
import com.example.petclinic.business.PetClinicBuisnessWorkflow;
import org.apache.catalina.core.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;


@SpringBootApplication
public class PetClinicClient {

    public static void main(String[] args) {

        ConfigurableApplicationContext context = SpringApplication.run(PetClinicClient.class, args);

        PetClinicBuisnessWorkflow business = (PetClinicBuisnessWorkflow) context.getBean("petClinicBuisnessWorkflow");

        business.runBusiness();

    }
}
