package com.example.petclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetClinicPet {

    public static void main(String[] args) {


        SpringApplication.run(PetClinicPet.class, args);
    }
}
